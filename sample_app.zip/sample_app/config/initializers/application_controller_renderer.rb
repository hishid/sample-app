# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '7ee9ee5a084268c6af742a2593a44d819129491dbd6f0d1ad7f4d6e82018ed17c2f0d18095cf2b383e0568243223db97c6428440d510e041ffa4803cfdf3d2ff'